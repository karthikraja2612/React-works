
import React from 'react';
const Singers = () => {
 return (
 <div>
 <h2>Singers</h2>
 <ul>
 <li>Singer 1 (Year)</li>
 <li>Singer 2 (Year)</li>
 </ul>
 </div>
 );
};
export default Singers;
